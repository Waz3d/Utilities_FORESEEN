#ifndef FMU_GUID_H_
#define FMU_GUID_H_

#define _FMU_GUID "{abb4bff1-d423-4e02-90d9-011f519869ff}"

#endif /* FMU_GUID_H_ */
