import json

mapper = """
{
"PlatooningAccelControlPositionRSF" : "PlatoonFORESEEN",
"platoon_fmu_unifmu" : "MEC"
}
"""
f = open("mm.json")

data = json.load(f)
json_mapper = json.loads(mapper)
for i in data["fmus"]:
	old = data["fmus"][i]
	for name in json_mapper:
		if name in old:
			new = old.replace(name, json_mapper[name])
			data["fmus"][i] = new

with open("new.json", "w") as my_file:
	json.dump(data, my_file)
